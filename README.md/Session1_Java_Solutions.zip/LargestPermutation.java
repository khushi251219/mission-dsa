import java.util.*;

public class LargestPermutation {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int k = sc.nextInt();
        int[] arr = new int[n];
        Map<Integer, Integer> pos = new HashMap<>();
        
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
            pos.put(arr[i], i);
        }

        for (int i = 0; i < n && k > 0; i++) {
            int maxVal = n - i;
            if (arr[i] != maxVal) {
                int idx = pos.get(maxVal);
                pos.put(arr[i], idx);
                pos.put(maxVal, i);
                int temp = arr[i];
                arr[i] = arr[idx];
                arr[idx] = temp;
                k--;
            }
        }

        for (int x : arr) {
            System.out.print(x + " ");
        }
    }
}
