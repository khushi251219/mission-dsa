import java.util.*;

public class SherlockAndAnagrams {
    public static int sherlockAndAnagrams(String s) {
        Map<String, Integer> map = new HashMap<>();
        int n = s.length();
        int count = 0;

        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j <= n; j++) {
                char[] sub = s.substring(i, j).toCharArray();
                Arrays.sort(sub);
                String key = new String(sub);
                map.put(key, map.getOrDefault(key, 0) + 1);
            }
        }

        for (int val : map.values()) {
            count += (val * (val - 1)) / 2;
        }

        return count;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int q = sc.nextInt();
        while (q-- > 0) {
            String s = sc.next();
            System.out.println(sherlockAndAnagrams(s));
        }
    }
}
