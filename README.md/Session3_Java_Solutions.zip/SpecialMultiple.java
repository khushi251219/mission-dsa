import java.util.*;

public class SpecialMultiple {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        while (t-- > 0) {
            int n = sc.nextInt();
            System.out.println(findMultiple(n));
        }
    }

    static String findMultiple(int n) {
        if (n == 1) return "1";
        Queue<String> q = new LinkedList<>();
        q.add("1");

        while (!q.isEmpty()) {
            String s = q.poll();
            long num = Long.parseLong(s);
            if (num % n == 0) return s;
            q.add(s + "0");
            q.add(s + "1");
        }
        return "";
    }
}
