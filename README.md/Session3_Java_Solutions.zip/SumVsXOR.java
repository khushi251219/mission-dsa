import java.util.*;

public class SumVsXOR {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        long n = sc.nextLong();
        int count = 0;
        long temp = n;

        while (temp > 0) {
            if ((temp & 1) == 0) count++;
            temp >>= 1;
        }

        long result = 1L << count;
        System.out.println(result);
    }
}
