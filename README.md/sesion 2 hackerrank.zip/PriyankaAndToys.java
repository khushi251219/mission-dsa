import java.util.*;

public class PriyankaAndToys {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] w = new int[n];
        for (int i = 0; i < n; i++) w[i] = sc.nextInt();
        System.out.println(priyankaAndToys(w));
    }

    public static int priyankaAndToys(int[] w) {
        Arrays.sort(w);
        int count = 1;
        int minWeight = w[0];
        for (int weight : w) {
            if (weight > minWeight + 4) {
                count++;
                minWeight = weight;
            }
        }
        return count;
    }
}